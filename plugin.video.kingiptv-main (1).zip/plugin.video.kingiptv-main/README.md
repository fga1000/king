## ADDON EXEMPLO PARA KODI

Funciona melhor apartir do kodi 19

[Download plugin.video.kingiptv.zip](https://github.com/zoreu/plugin.video.kingiptv/releases/download/0.0.1/plugin.video.kingiptv.zip)

